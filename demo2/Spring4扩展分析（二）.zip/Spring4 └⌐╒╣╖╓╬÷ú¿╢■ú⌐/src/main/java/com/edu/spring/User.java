package com.edu.spring;

public class User {
	
	public void init(){
		System.out.println("user init");
	}
}
