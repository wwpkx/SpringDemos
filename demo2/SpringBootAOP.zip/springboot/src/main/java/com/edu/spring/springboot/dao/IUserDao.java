package com.edu.spring.springboot.dao;

public interface IUserDao {
	public void add(String username, String password);
}
