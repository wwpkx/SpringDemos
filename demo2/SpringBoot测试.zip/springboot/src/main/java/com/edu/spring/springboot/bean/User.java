package com.edu.spring.springboot.bean;

import org.springframework.stereotype.Component;

@Component
public class User {

}
