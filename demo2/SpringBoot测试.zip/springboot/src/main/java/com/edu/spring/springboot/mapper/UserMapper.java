package com.edu.spring.springboot.mapper;

public interface UserMapper {
	public Integer createUser(String username) ;
}