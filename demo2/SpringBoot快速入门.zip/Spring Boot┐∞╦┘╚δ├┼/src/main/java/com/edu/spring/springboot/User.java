package com.edu.spring.springboot;

import org.springframework.stereotype.Component;

@Component
public class User {

}
