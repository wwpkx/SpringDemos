package com.edu.spring;

import org.springframework.stereotype.Controller;

//一般用在展现层
@Controller
public class UserController {

}
