package com.edu.spring;

public class CarFactory {

	public Car create(){
		return new Car();
	}
}
