package com.edu.spring;

import org.springframework.stereotype.Repository;

//一般用在数据访问层上面
@Repository
public class UserDao {

}
