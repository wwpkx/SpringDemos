package com.edu.spring;

public class Car {

}
