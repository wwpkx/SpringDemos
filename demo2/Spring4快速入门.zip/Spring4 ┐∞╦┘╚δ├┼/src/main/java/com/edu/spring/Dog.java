package com.edu.spring;

public class Dog {

	public void init(){
		System.out.println("=======init======");
	}
	
	public void destroy(){
		System.out.println("=======destroy=========");
	}
}
