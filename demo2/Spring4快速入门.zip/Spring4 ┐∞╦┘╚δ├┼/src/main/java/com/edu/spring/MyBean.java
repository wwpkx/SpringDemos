package com.edu.spring;

public class MyBean {

}
