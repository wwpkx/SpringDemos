package com.edu.spring.springboot;

public interface EncodingConvert {

}
