package com.edu.spring;

import org.springframework.context.ApplicationContext;

public interface SpringContextAware {
	public void setApplicationContext(ApplicationContext applicationContext);
}
