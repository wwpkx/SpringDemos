package com.edu.spring.springboot;

public class User {

}
