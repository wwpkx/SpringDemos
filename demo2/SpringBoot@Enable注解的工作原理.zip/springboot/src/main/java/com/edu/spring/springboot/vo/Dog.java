package com.edu.spring.springboot.vo;

import org.springframework.stereotype.Component;

@Component
public class Dog {

}
