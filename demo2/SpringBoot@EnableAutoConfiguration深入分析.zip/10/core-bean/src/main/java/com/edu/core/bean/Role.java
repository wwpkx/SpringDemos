package com.edu.core.bean;

public class Role {

}
